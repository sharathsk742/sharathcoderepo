package com.example.demo.model;

enum Priority {
    HIGH,
    MEDIUM,
    LOW
}