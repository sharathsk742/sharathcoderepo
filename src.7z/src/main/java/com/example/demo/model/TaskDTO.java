package com.example.demo.model;

import java.time.LocalDate;

import org.antlr.v4.runtime.misc.NotNull;

public class TaskDTO {
    
    private String title;

    private String description;

    
    private LocalDate dueDate;

    // Getters and setters
}
